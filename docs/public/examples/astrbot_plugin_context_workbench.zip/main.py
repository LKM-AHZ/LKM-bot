"""Read-only context usage view for the ChatUI workbench."""

import json
import time
from typing import Any

from bot.api.event import BotMessageEvent, filter
from bot.api.star import Context, Star
from bot.api.web import error_response, json_response, request
from bot.core.agent.context.token_counter import EstimateTokenCounter
from bot.core.agent.message import Message
from bot.core.provider.entities import ProviderRequest
from bot.core.utils.llm_metadata import LLM_METADATAS


class ContextWorkbenchPlugin(Star):
    """Expose aggregate estimates without sending conversation text to the view."""


    def __init__(self, context: Context):
        super().__init__(context)
        self.snapshots: dict[str, dict] = {}
        self.counter = EstimateTokenCounter()
        context.register_web_api(
            "/bot_plugin_context_workbench/usage",
            self.usage,
            ["GET"],
            "Read the authenticated user's current context estimates",
        )

    def estimate(self, value: Any) -> int:
        """Estimate a serialized request part using LKMBot's token counter.

        Args:
            value: Text or a JSON-compatible request part.

        Returns:
            Estimated tokens, including serialized structure for non-text data.
        """
        if not value:
            return 0
        text = (
            value
            if isinstance(value, str)
            else json.dumps(value, ensure_ascii=False, default=str)
        )
        return self.counter.count_tokens([Message(role="user", content=text)])

    @filter.on_llm_request(priority=-1000)
    async def capture(self, event: BotMessageEvent, req: ProviderRequest):
        """Capture aggregate counts for the latest observed request.

        Args:
            event: Originating message event.
            req: Request before provider serialization.
        """
        if event.get_platform_name() != "webchat":
            return
        provider = await self.context.get_using_provider_async(event.unified_msg_origin)
        model = req.model or (provider.get_model() if provider else "")
        capacity = (
            provider.provider_config.get("max_context_tokens", 0) if provider else 0
        )
        if not capacity:
            capacity = LLM_METADATAS.get(model, {}).get("limit", {}).get("context")
        schemas = req.func_tool.openai_schema() if req.func_tool else []
        tool_details = [
            {
                "label": item.get("function", {}).get("name", "tool"),
                "tokens": self.estimate(item),
            }
            for item in schemas
        ]
        categories = [
            {
                "id": "system",
                "label": "系统指令",
                "tokens": self.estimate(req.system_prompt),
            },
            {
                "id": "tools",
                "label": "工具定义",
                "tokens": sum(item["tokens"] for item in tool_details),
                "items": tool_details,
            },
            {
                "id": "conversation",
                "label": "对话",
                "tokens": self.estimate(
                    [item for item in req.contexts if item.get("role") != "tool"]
                )
                + self.estimate(req.prompt),
            },
            {
                "id": "results",
                "label": "工具结果",
                "tokens": self.estimate(
                    [item for item in req.contexts if item.get("role") == "tool"]
                )
                + self.estimate(req.tool_calls_result),
            },
        ]
        self.snapshots[event.unified_msg_origin] = {
            "model": model,
            "capacity": capacity or None,
            "categories": categories,
            "source": "request",
            "updated_at": time.time(),
        }
        # Keep only aggregate snapshots and bound the plugin's memory footprint.
        if len(self.snapshots) > 128:
            oldest = min(
                self.snapshots, key=lambda key: self.snapshots[key]["updated_at"]
            )
            self.snapshots.pop(oldest)

    async def usage(self):
        """Return estimates only after checking ownership of the requested session.

        Returns:
            Authenticated aggregate counts, or an inaccessible-session response.
        """
        session_id = request.query.get("session_id", "")
        session = await self.context.get_db().get_platform_session_by_id(session_id)
        if not session or session.creator != request.username:
            return error_response("会话不可访问。", status_code=404)
        kind = "GroupMessage" if session.is_group else "FriendMessage"
        umo = f"{session.platform_id}:{kind}:{session.platform_id}!{session.creator}!{session.session_id}"
        snapshot = self.snapshots.get(umo)
        if snapshot:
            return json_response(
                {
                    **snapshot,
                    "session_id": session_id,
                    "session_title": session.display_name,
                    "estimated": True,
                }
            )
        conversation_id = (
            await self.context.conversation_manager.get_curr_conversation_id(umo)
        )
        conversation = (
            await self.context.conversation_manager.get_conversation(
                umo, conversation_id
            )
            if conversation_id
            else None
        )
        history = (
            json.loads(conversation.history)
            if conversation and conversation.history
            else []
        )
        provider = await self.context.get_using_provider_async(umo)
        model = provider.get_model() if provider else ""
        capacity = (
            provider.provider_config.get("max_context_tokens", 0) if provider else 0
        )
        if not capacity:
            capacity = LLM_METADATAS.get(model, {}).get("limit", {}).get("context")
        return json_response(
            {
                "session_id": session_id,
                "session_title": session.display_name,
                "model": model,
                "capacity": capacity or None,
                "source": "history",
                "estimated": True,
                "updated_at": None,
                "categories": [
                    {"id": "system", "label": "系统指令", "tokens": None},
                    {"id": "tools", "label": "工具定义", "tokens": None},
                    {
                        "id": "conversation",
                        "label": "对话",
                        "tokens": self.estimate(
                            [item for item in history if item.get("role") != "tool"]
                        ),
                    },
                    {
                        "id": "results",
                        "label": "工具结果",
                        "tokens": self.estimate(
                            [item for item in history if item.get("role") == "tool"]
                        ),
                    },
                ],
            }
        )
