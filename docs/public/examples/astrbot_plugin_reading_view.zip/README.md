# 阅读清单 / Reading list

在 WebUI 插件管理中安装 ZIP，然后在 ChatUI 发送 `/reading`，或让模型调用 `open_reading_list`。

卡片支持筛选、标记已读和添加书目。每张卡片独立保存，操作通过 `filter.ui_action` 更新数据，不调用模型。页面使用透明背景和共享主题 tokens，无构建步骤和外部依赖。

Install the ZIP from the WebUI plugin manager, then send `/reading` in ChatUI or ask the model to call `open_reading_list`.

Filter books, mark them as read, or add a title. Each card saves its own data through `filter.ui_action`; interactions do not call a model. The view has a transparent background, uses shared theme tokens, and needs no frontend build or external dependencies.
