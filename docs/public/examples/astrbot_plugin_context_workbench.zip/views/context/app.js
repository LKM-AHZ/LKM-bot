const bridge = window.BotPluginView;
const el = (id) => document.getElementById(id);
const format = (value) => value == null ? '未知' : value >= 1000000 ? `${(value / 1000000).toFixed(1)}M` : value >= 1000 ? `${(value / 1000).toFixed(1)}K` : String(value);
let sessionId = null;
let requestVersion = 0;

async function refresh() {
  const version = ++requestVersion;
  el('content').hidden = true;
  el('status').hidden = false;
  if (!sessionId) { el('status').textContent = '打开一个会话后，这里会显示它的上下文用量。'; el('model').textContent = ''; return; }
  el('status').textContent = '读取上下文…';
  try {
    const response = await bridge.apiGet('usage', { session_id: sessionId });
    if (version !== requestVersion) return;
    const data = response.data ?? response;
    const categories = data.categories;
    const total = categories.reduce((sum, part) => sum + (part.tokens ?? 0), 0);
    const complete = categories.every(part => part.tokens != null);
    const limit = data.capacity;
    el('model').textContent = data.model || '未选择模型';
    el('model').title = data.model || '';
    el('session').textContent = data.session_title || '当前会话';
    el('total').textContent = `≈ ${format(total)}`;
    el('capacity').textContent = limit ? `/ ${format(limit)} tokens` : 'tokens · 容量未知';
    const percent = limit ? Math.round(total / limit * 100) : null;
    el('percent').textContent = percent == null ? '' : `${complete ? '' : '≥ '}${percent}%`;
    el('percent').className = `percent ${percent >= 95 ? 'full' : percent >= 80 ? 'warning' : ''}`;
    el('basis').textContent = complete ? '最近一次请求 · 按文本与结构估算' : '当前历史 · 部分来源尚未观测';
    el('remaining').textContent = !limit ? '未配置或识别上下文容量' : !complete ? '剩余容量待完整请求确认' : `约 ${format(Math.max(0, limit - total))} tokens 可用`;
    el('note').textContent = '数值使用 LKMBot 的估算规则，可能与模型实际分词不同。文件和记忆未被单独标注时，会计入其所在消息。' + (data.source === 'history' ? ' 启用插件后发送一条消息，可捕获系统指令和工具定义。' : ' 这里展示最近观测到的请求；点击刷新获取更新。');
    const scale = Math.max(limit || total, total, 1);
    const cells = [];
    let previous = 0, cumulative = 0;
    for (const part of categories) {
      cumulative += part.tokens ?? 0;
      const end = Math.min(280, Math.round(cumulative / scale * 280));
      for (let i = previous; i < end; i++) {
        const cell = document.createElement('span'); cell.className = 'cell'; cell.dataset.part = part.id;
        cell.style.background = `var(--${part.id})`; cell.title = `${part.label} · ${format(part.tokens)}`; cells.push(cell);
      }
      previous = end;
    }
    while (cells.length < 280) { const cell = document.createElement('span'); cell.className = 'cell'; cell.title = complete ? '可用' : '未观测 / 可用'; cells.push(cell); }
    el('grid').replaceChildren(...cells);
    el('grid').setAttribute('aria-label', `${format(total)} tokens${limit ? `，容量 ${format(limit)}` : ''}，估算值`);
    const rows = categories.map(part => {
      const row = document.createElement(part.items?.length ? 'details' : 'div'); row.className = 'category'; row.style.setProperty('--category', `var(--${part.id})`);
      const line = document.createElement(part.items?.length ? 'summary' : 'div'); line.className = 'category-row';
      const swatch = document.createElement('span'); swatch.className = 'swatch';
      const label = document.createElement('span'); label.className = 'category-label'; label.textContent = part.label;
      const count = document.createElement('span'); count.className = 'count'; count.textContent = format(part.tokens);
      line.append(swatch, label, count); row.append(line);
      for (const item of part.items || []) { const child = document.createElement('div'); child.className = 'tool-item'; const name = document.createElement('span'); name.textContent = item.label; name.title = item.label; const amount = document.createElement('span'); amount.textContent = format(item.tokens); child.append(name, amount); row.append(child); }
      row.addEventListener('mouseenter', () => cells.forEach(cell => cell.style.opacity = cell.dataset.part === part.id ? '1' : '0.2'));
      row.addEventListener('mouseleave', () => cells.forEach(cell => cell.style.opacity = '1'));
      return row;
    });
    el('categories').replaceChildren(...rows);
    el('status').hidden = true; el('content').hidden = false;
  } catch (error) {
    if (version !== requestVersion) return;
    el('status').textContent = '无法读取当前会话的上下文，请确认插件已启用，然后重新打开此标签。';
    console.error('Failed to load context usage', error);
  }
}
el('refresh').addEventListener('click', refresh);
await bridge.ready();
bridge.onContext(context => {
  const next = context.sessionId || null;
  if (next !== sessionId) { sessionId = next; refresh(); }
});
if (!sessionId) refresh();
